﻿using System.Collections.Generic;

namespace BetterBooks.Models
{
    public class MyBooksViewModel
    {
        public List<Book> MyBooks { get; set; }
    }
}