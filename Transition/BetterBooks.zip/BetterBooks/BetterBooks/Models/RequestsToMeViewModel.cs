﻿using System.Collections.Generic;

namespace BetterBooks.Models
{
    public class RequestsToMeViewModel
    {
        public List<Book> BooksRequestsToMe { get; set; }
    }
}