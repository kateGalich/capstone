﻿using System.Collections.Generic;

namespace BetterBooks.Models
{
    public class RequestedByMeViewModel
    {
        public List<BookRequest> BooksRequestedByMe { get; set; }
    }
}